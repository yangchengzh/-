//
//  ViewController.h
//  ZhiFuBao
//
//  Created by dyso on 16/8/4.
//  Copyright © 2016年 yangzhicheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

+ (NSInteger)indexOfPoint:(CGPoint)point
               withUiview:(UIView *)view
                singArray:(NSMutableArray *)singArray;
@end

