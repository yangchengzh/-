//
//  DetailViewController.h
//  ZhiFuBao
//
//  Created by dyso on 16/8/5.
//  Copyright © 2016年 yangzhicheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@end
